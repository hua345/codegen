
    /**
     * {{.Description}}
     * @param param 入参
     * @return 出参
     */
    {{.ResponseDTOName}} {{.MethodName}}({{.RequestDTOName}} param);